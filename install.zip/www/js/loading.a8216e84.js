import{r as a}from"./arco.73db23e5.js";function l(e=!1){const o=a(e);return{loading:o,setLoading:t=>{o.value=t},toggle:()=>{o.value=!o.value}}}export{l as u};
